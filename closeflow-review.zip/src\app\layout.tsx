import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import ToastProvider from "@/components/ToastProvider"
import "./globals.css"

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
})

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
})

export const metadata: Metadata = {
  title: "CloseFlow | AI-powered CRM",
  description: "A polished AI-powered CRM experience for modern revenue teams.",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}>
      <body className="min-h-full bg-black text-white">
        <ToastProvider />
        {children}
      </body>
    </html>
  )
}
