"use client"

import { useRouter } from "next/navigation"
import { getHealthScore, getPriorityScore } from "@/lib/scoring"
import { usePriorityAI } from "@/hooks/usePriorityAI"
import { leadDisplayName, leadCompany } from "@/lib/utils"

type PriorityLead = {
  id: string
  name: string
  company: string
  status: string
  value: number
  created_at: string
  notes?: string | null
  stage_changed_at?: string | null
}

type PriorityDealsCardProps = {
  leads: PriorityLead[]
}

export default function PriorityDealsCard({ leads }: PriorityDealsCardProps) {

  const router = useRouter()
  const aiAnalysis = usePriorityAI(leads)


  return (

    <section
      className="rounded-2xl border border-white/10 bg-[#111] p-6"
      aria-labelledby="priority-deals-heading"
    >

      <div className="flex items-center justify-between">

        <div>
          <p className="text-sm text-zinc-400">
            AI priority scoring
          </p>

          <h2
            id="priority-deals-heading"
            className="text-lg font-semibold text-white"
          >
            Deals to focus on
          </h2>
        </div>


        <div className="text-sm text-zinc-500">
          Top {leads.length}
        </div>

      </div>

      <div className="
        mb-5
        rounded-xl
        border
        border-cyan-500/20
        bg-cyan-500/10
        p-4
      ">

        <p className="text-xs uppercase tracking-wider text-cyan-400">
          AI recommendation
        </p>


        {aiAnalysis.headline && (
          <h3 className="text-lg font-semibold text-white">
            {aiAnalysis.headline}
          </h3>
        )}

        <p className="mt-2 text-sm text-zinc-200">
          {aiAnalysis.explanation ||
            "Analyzing priority opportunities..."}
        </p>


        {aiAnalysis.priorityReason && (
          <p className="mt-3 text-sm text-zinc-300">
            <span className="text-cyan-400">
              Why:
            </span>{" "}
            {aiAnalysis.priorityReason}
          </p>
        )}


        {aiAnalysis.riskLevel && (

          <div className="mt-4 flex items-center gap-3">

            <span className="text-sm text-zinc-400">
              Risk:
            </span>


            <span
              className={`
                rounded-full
                px-3
                py-1
                text-xs
                font-semibold

                ${
                  aiAnalysis.riskLevel === "High"
                    ? "bg-red-500/10 text-red-400 border border-red-500/20"
                    : aiAnalysis.riskLevel === "Medium"
                    ? "bg-yellow-500/10 text-yellow-400 border border-yellow-500/20"
                    : "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                }
              `}
            >

              {aiAnalysis.riskLevel === "High" && "🔴 "}
              {aiAnalysis.riskLevel === "Medium" && "🟡 "}
              {aiAnalysis.riskLevel === "Low" && "🟢 "}

              {aiAnalysis.riskLevel}

            </span>

          </div>

        )}

        {aiAnalysis.nextAction && (
          <p className="mt-3 text-sm text-cyan-300">
            Next:
            <span className="ml-1 text-white">
              {aiAnalysis.nextAction}
            </span>
          </p>
        )}
      </div>

      <div className="mt-5 space-y-3">

        {leads.map((lead) => {

          const health = getHealthScore(lead)
          const priority = getPriorityScore(lead)


          const healthLabel =
            health >= 70
              ? "Healthy"
              : health >= 50
              ? "Watch"
              : "At risk"


          const healthStyle =
            health >= 70
              ? "text-emerald-400 bg-emerald-500/10"
              : health >= 50
              ? "text-yellow-400 bg-yellow-500/10"
              : "text-red-400 bg-red-500/10"



          return (

            <button
              key={lead.id}
              onClick={() => router.push(`/leads/${lead.id}`)}
              className="
                w-full
                text-left
                rounded-xl
                border
                border-white/10
                bg-black/30
                p-4
                transition
                hover:border-cyan-500/40
                hover:bg-black/50
              "
            >


              <div className="flex items-start justify-between gap-4">


                <div>

                  <p className="font-semibold text-white">
                    {leadDisplayName(lead)}
                  </p>


                  <p className="text-sm text-zinc-500">
                    {leadCompany(lead)}
                  </p>


                </div>



                <div className="text-right">

                  <p className="text-sm font-semibold text-cyan-400">
                    ⚡ {priority}/100
                  </p>


                  <span
                    className={`
                      inline-block
                      mt-1
                      rounded-full
                      px-2
                      py-1
                      text-xs
                      ${healthStyle}
                    `}
                  >
                    {healthLabel}
                  </span>


                </div>


              </div>



              <div className="mt-4 flex justify-between text-sm">

                <span className="text-zinc-400">
                  Stage:
                  <span className="ml-1 text-white">
                    {lead.status}
                  </span>
                </span>



                <span className="font-semibold text-purple-400">
                  €
                  {lead.value.toLocaleString("de-DE")}
                </span>


              </div>



              <div className="mt-3 h-2 overflow-hidden rounded-full bg-zinc-800">

                <div
                  className="h-full rounded-full bg-gradient-to-r from-cyan-500 to-emerald-500"
                  style={{
                    width: `${priority}%`
                  }}
                />

              </div>


            </button>

          )

        })}


      </div>


    </section>

  )
}
